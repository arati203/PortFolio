package com.hotelmanagement;

		import java.awt.Color;
		import java.awt.Font;
		import java.awt.Image;
		import java.awt.event.ActionEvent;
		import java.awt.event.ActionListener;
		import java.sql.ResultSet;

		import javax.swing.ImageIcon;
		import javax.swing.JButton;
		import javax.swing.JComboBox;
		import javax.swing.JFrame;
		import javax.swing.JLabel;
		import javax.swing.JOptionPane;
		import javax.swing.JTextField;

		public class AddDriver extends JFrame implements ActionListener {

			JButton add, cancel;
			JTextField tfname, tfage, tfcompany, tfmodel, tfloction;
			JComboBox availablecombo, gendercombo;
			
			AddDriver(){
				
				getContentPane().setBackground(Color.WHITE);
				setLayout(null);
				
				JLabel lb1driver=new JLabel("ADD DRIVERS");
				lb1driver.setBounds(150, 10, 150, 30);
				lb1driver.setFont(new Font("Tahoma", Font.BOLD, 18));
				add(lb1driver);
				
				JLabel lb1name=new JLabel("Name:");
				lb1name.setBounds(60, 70, 120, 30);
				lb1name.setFont(new Font("Tahoma", Font.PLAIN, 16));
				add(lb1name);

				tfname= new JTextField();
				tfname.setBounds(200, 70, 150, 30);
				add(tfname);
				
				JLabel lb1available=new JLabel("Age:");
				lb1available.setBounds(60, 110, 120, 30);
				lb1available.setFont(new Font("Tahoma", Font.PLAIN, 16));
				add(lb1available);
				
				tfage= new JTextField();
				tfage.setBounds(200, 110, 150, 30);
				add(tfage);
				
				JLabel lb1gender=new JLabel("Gender:");
				lb1gender.setBounds(60, 150, 120, 30);
				lb1gender.setFont(new Font("Tahoma", Font.PLAIN, 16));
				add(lb1gender);
				
				String genderOption[]= {"Male", "Female"}; 
				gendercombo= new JComboBox(genderOption);
				gendercombo.setBounds(200, 150, 150, 30);
				gendercombo.setBackground(Color.WHITE);
				add(gendercombo);	
				
				JLabel lb1company=new JLabel("Car Company:");
				lb1company.setBounds(60, 190, 120, 30);
				lb1company.setFont(new Font("Tahoma", Font.PLAIN, 16));
				add(lb1company);

				tfcompany= new JTextField();
				tfcompany.setBounds(200, 190, 150, 30);
				add(tfcompany);
				
				JLabel lb1model=new JLabel("Car Model:");
				lb1model.setBounds(60, 230, 120, 30);
				lb1model.setFont(new Font("Tahoma", Font.PLAIN, 16));
				add(lb1model);

				tfmodel= new JTextField();
				tfmodel.setBounds(200, 230, 150, 30);
				add(tfmodel);
				
				JLabel lb1available1=new JLabel("Available:");
				lb1available1.setBounds(60, 270, 120, 30);
				lb1available1.setFont(new Font("Tahoma", Font.PLAIN, 16));
				add(lb1available1);
				
				String availableOption[]= {"Available", "Busy"}; 
				availablecombo= new JComboBox(availableOption);
				availablecombo.setBounds(200, 270, 150, 30);
				availablecombo.setBackground(Color.WHITE);
				add(availablecombo);	
				
				JLabel lb1location=new JLabel("Location:");
				lb1location.setBounds(60, 310, 120, 30);
				lb1location.setFont(new Font("Tahoma", Font.PLAIN, 16));
				add(lb1location);

				tfloction= new JTextField();
				tfloction.setBounds(200, 310, 150, 30);
				add(tfloction);
				
				add= new JButton("Add Driver");
				add.setBounds(60, 370, 130, 30);
				add.setBackground(Color.BLACK);
				add.setForeground(Color.WHITE);
				add.addActionListener(this);
				add(add);

				cancel= new JButton("Cancel");
				cancel.setBounds(220, 370, 130, 30);
				cancel.setBackground(Color.BLACK);
				cancel.setForeground(Color.WHITE);
				cancel.addActionListener(this);
				add(cancel);
				
				ImageIcon i1= new ImageIcon(ClassLoader.getSystemResource("eleven.jpg"));
				Image i2=i1.getImage().getScaledInstance(500, 300, Image.SCALE_DEFAULT);
				ImageIcon i3=new ImageIcon(i2);
				JLabel image =new JLabel(i3);
				image.setBounds(400, 30, 500, 300);
				add(image);
				
			
				setBounds(300, 150, 980, 470);	
		        setVisible(true);
			}
			
			public static void main(String[] args) {
				new AddDriver();
			}

			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(e.getSource()==add) {
					String name=tfname.getText();
					String age=tfage.getText();
			        String gender=(String)gendercombo.getSelectedItem();
					String compny=tfcompany.getText();
					String model=tfmodel.getText();
					String c=(String)availablecombo.getSelectedItem();	
					String location=tfloction.getText();
					
					try {
					Conn con=new Conn();	
String str="Insert into driver values('"+name+"', '"+age+"','"+gender+"', '"+compny+"','"+model+"','"+c+"', '"+location+"')";
		 		con.s.execute(str);
		 		JOptionPane.showMessageDialog(null, "New Driver Added Successfully");
				setVisible(false);
			}
			catch(Exception ae) {
			ae.printStackTrace();	
			}
			}
			}
	}

