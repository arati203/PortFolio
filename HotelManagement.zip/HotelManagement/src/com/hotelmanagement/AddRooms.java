package com.hotelmanagement;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class AddRooms extends JFrame implements ActionListener {

	JButton add, cancel;
	JTextField tfroom, tfprice;
	JComboBox typecombo, avaiblecombo, cleancombo;
	
	AddRooms(){
		
		getContentPane().setBackground(Color.WHITE);
		setLayout(null);
		
		JLabel lb1room=new JLabel("ADD ROOMS");
		lb1room.setBounds(150, 20, 120, 30);
		lb1room.setFont(new Font("Tahoma", Font.BOLD, 18));
		add(lb1room);
		
		JLabel lb1roomno=new JLabel("Room Number:");
		lb1roomno.setBounds(60, 80, 120, 30);
		lb1roomno.setFont(new Font("Tahoma", Font.PLAIN, 16));
		add(lb1roomno);

		tfroom= new JTextField();
		tfroom.setBounds(200, 80, 150, 30);
		add(tfroom);
		
		JLabel lb1available=new JLabel("Available:");
		lb1available.setBounds(60, 130, 120, 30);
		lb1available.setFont(new Font("Tahoma", Font.PLAIN, 16));
		add(lb1available);
		
		String availableOption[]= {"Available", "Occupied"}; 
		avaiblecombo= new JComboBox(availableOption);
		avaiblecombo.setBounds(200, 130, 150, 30);
		avaiblecombo.setBackground(Color.WHITE);
		add(avaiblecombo);
		
		JLabel lb1clean=new JLabel("Cleaning Status:");
		lb1clean.setBounds(60, 180, 120, 30);
		lb1clean.setFont(new Font("Tahoma", Font.PLAIN, 16));
		add(lb1clean);
		
		String cleanOption[]= {"Cleaned", "Dirty"}; 
		cleancombo= new JComboBox(cleanOption);
		cleancombo.setBounds(200, 180, 150, 30);
		cleancombo.setBackground(Color.WHITE);
		add(cleancombo);	
		
		JLabel lb1price=new JLabel("Price:");
		lb1price.setBounds(60, 230, 120, 30);
		lb1price.setFont(new Font("Tahoma", Font.PLAIN, 16));
		add(lb1price);

		tfprice= new JTextField();
		tfprice.setBounds(200, 230, 150, 30);
		add(tfprice);
		
		JLabel lb1type=new JLabel("Bed Type:");
		lb1type.setBounds(60, 280, 120, 30);
		lb1type.setFont(new Font("Tahoma", Font.PLAIN, 16));
		add(lb1type);
		
		String typeOption[]= {"Single Bed", "Double Bed"}; 
		typecombo= new JComboBox(typeOption);
		typecombo.setBounds(200, 280, 150, 30);
		typecombo.setBackground(Color.WHITE);
		add(typecombo);	
		
		add= new JButton("Add Room");
		add.setBounds(60, 350, 130, 30);
		add.setBackground(Color.BLACK);
		add.setForeground(Color.WHITE);
		add.addActionListener(this);
		add(add);

		cancel= new JButton("Cancel");
		cancel.setBounds(220, 350, 130, 30);
		cancel.setBackground(Color.BLACK);
		cancel.setForeground(Color.WHITE);
		cancel.addActionListener(this);
		add(cancel);
		
		ImageIcon i1= new ImageIcon(ClassLoader.getSystemResource("twelve.jpg"));
		JLabel image =new JLabel(i1);
		image.setBounds(400, 30, 500, 300);
		add(image);
		
	
		setBounds(330, 100, 940, 470);	
        setVisible(true);
	}
	
	public static void main(String[] args) {
		new AddRooms();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==add) {
			String roomnumber=tfroom.getText();
		String availability=(String)avaiblecombo.getSelectedItem();	
		String status=(String)cleancombo.getSelectedItem();
			String price=tfprice.getText();
			String type=(String)typecombo.getSelectedItem();
			
			try {
			Conn c=new Conn();	
 		String str="Insert into room values('"+roomnumber+"', '"+availability+"','"+status+"', '"+price+"', '"+type+"')";
 		c.s.execute(str);
 		JOptionPane.showMessageDialog(null, "New Room Added Successfully");
		setVisible(false);
	}
	catch(Exception ae) {
	ae.printStackTrace();	
	}
	}
	}
}
